jupyter-nbconvert --execute --to html issue-245.ipynb
