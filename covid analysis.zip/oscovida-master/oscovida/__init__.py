from .oscovida import *
from .oscovida import _germany_get_population_backup_data_raw
from .metadata import MetadataRegion


__version__ = "0.2.6"
