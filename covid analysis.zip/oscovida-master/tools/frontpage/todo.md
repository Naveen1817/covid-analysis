Add script to update figures from South Korea in subfolder figures
