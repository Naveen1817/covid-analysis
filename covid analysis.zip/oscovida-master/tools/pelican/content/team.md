Title: Team
Date: 2020-05-27 21:00
tags: about
slug: team

Following early work by [Hans Fangohr](http://fangohr.github.io), members of the
European research project [Photon and Neutron Open Science Cloud
(PANOSC)](http://panosc.eu) and the Data Analysis Group of [European
XFEL](https://xfel.eu) contribute to the project here, including Robert Rosca,
[Yury Kirienko](https://github.com/kirienko/), [Thomas
Michelat](https://github.com/tmichela), [David Doblas
Jiménez](https://git.elnota.space/daviddoji/), [Ebad
Kamil](https://github.com/ebadkamil), and Jacek Generowicz, and others.



