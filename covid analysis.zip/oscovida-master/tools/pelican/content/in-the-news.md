title: OSCOVIDA in the news
date: 15-06-2020

- [6 July 2020, Data from Hungary in OSCOVIDA](https://cordis.europa.eu/article/id/421539-hungarian-contribution-to-panosc-oscovida-allows-following-covid-19-pandemic-in-the-country-a)
- [30 June 2020, Update from Germany Physics Society on COVID19 research](https://www.dpg-physik.de/veroeffentlichungen/publikationen/physikkonkret/physikkonkret-46)
- [15 June 2020, European XFEL News item (english version,](https://www.xfel.eu/news_and_events/news/index_eng.html?openDirectAnchor=1788&two_columns=0)
  [deutsche
  Version)](https://www.xfel.eu/aktuelles/news/index_ger.html?openDirectAnchor=1788&two_columns=0)
- [3 June 2020 Digitum, University Murcia, Spain (in spanish)](http://digitum-um.blogspot.com/2020/06/descubra-oscovida-open-science-covid.html)
- [ 27 May 2020 CORDIS website](https://cordis.europa.eu/article/id/418274-discover-oscovida-the-panosc-open-science-covid-analysis-platform-tracking-data-about-covid19)
- [ 27 May 2020 PaNOSC website ](https://www.panosc.eu/news/panosc-open-science-covid-analysis-platform-now-online/)
- [ 27 May 2020 YouTube](https://www.youtube.com/watch?v=1_oDc_vptBQ)
- [ 27 May 2020 Twitter](https://twitter.com/Panosc_eu/status/1265220561174695937)
