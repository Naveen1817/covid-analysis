rsync -auv 2020-04-30-bbc-germany-increasing.ipynb ../../../wwwroot/ipynb
