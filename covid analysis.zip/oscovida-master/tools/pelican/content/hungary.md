title: Tracking plots:  Hungary
tags: Data, Plots, Tracking plots:  Hungary
save-as: hungary
slug: hungary
date: 2020/07/03 19:24


| Location                                                                    | Total cases   | Total deaths   |   New cases last week |
|:----------------------------------------------------------------------------|:--------------|:---------------|----------------------:|
| [Hungary: Borsod-Abaúj-Zemplén](html/Hungary-Borsod-Abaúj-Zemplén.html)     | 62            | missing        |                     0 |
| [Hungary: Budapest](html/Hungary-Budapest.html)                             | 1,977         | missing        |                    31 |
| [Hungary: Bács-Kiskun](html/Hungary-Bács-Kiskun.html)                       | 20            | missing        |                     0 |
| [Hungary: Somogy](html/Hungary-Somogy.html)                                 | 22            | missing        |                     0 |
| [Hungary: Nógrád](html/Hungary-Nógrád.html)                                 | 51            | missing        |                     0 |
| [Hungary: Veszprém](html/Hungary-Veszprém.html)                             | 63            | missing        |                     0 |
| [Hungary: Tolna](html/Hungary-Tolna.html)                                   | 13            | missing        |                     0 |
| [Hungary: Komárom-Esztergom](html/Hungary-Komárom-Esztergom.html)           | 307           | missing        |                     5 |
| [Hungary: Hajú-Bihar](html/Hungary-Hajú-Bihar.html)                         | 22            | missing        |                    -5 |
| [Hungary: Pest](html/Hungary-Pest.html)                                     | 618           | missing        |                    13 |
| [Hungary: Fejér](html/Hungary-Fejér.html)                                   | 376           | missing        |                     0 |
| [Hungary: Zala](html/Hungary-Zala.html)                                     | 262           | missing        |                     2 |
| [Hungary: Baranya](html/Hungary-Baranya.html)                               | 40            | missing        |                     1 |
| [Hungary: Csongrád](html/Hungary-Csongrád.html)                             | 112           | missing        |                    -5 |
| [Hungary: Szabolcs-Szatmár-Bereg](html/Hungary-Szabolcs-Szatmár-Bereg.html) | 51            | missing        |                     1 |
| [Hungary: Békés](html/Hungary-Békés.html)                                   | 13            | missing        |                     0 |
| [Hungary: Vas](html/Hungary-Vas.html)                                       | 17            | missing        |                     0 |
| [Hungary: Jász-Nagykun-Szolnok](html/Hungary-Jász-Nagykun-Szolnok.html)     | 19            | missing        |                     0 |
| [Hungary: Heves](html/Hungary-Heves.html)                                   | 14            | missing        |                     0 |
| [Hungary: Győr-Moson-Sopron](html/Hungary-Győr-Moson-Sopron.html)           | 86            | missing        |                     0 |
