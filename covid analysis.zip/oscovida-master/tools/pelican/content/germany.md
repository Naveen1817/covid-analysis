title: Tracking plots:  Germany
tags: Data, Plots, Tracking plots:  Germany
save-as: germany
slug: germany
date: 2020/08/22 00:49


| Location                                                                                                                    | Total cases   |   Total deaths |   New cases last week |
|:----------------------------------------------------------------------------------------------------------------------------|:--------------|---------------:|----------------------:|
| [Germany: Baden-Württemberg : LK Enzkreis](html/Germany-Baden-Württemberg-LK-Enzkreis.html)                                 | 716           |             22 |                    11 |
| [Germany: Baden-Württemberg : LK Biberach](html/Germany-Baden-Württemberg-LK-Biberach.html)                                 | 676           |             36 |                    25 |
| [Germany: Baden-Württemberg : LK Bodenseekreis](html/Germany-Baden-Württemberg-LK-Bodenseekreis.html)                       | 368           |              8 |                    20 |
| [Germany: Baden-Württemberg : LK Calw](html/Germany-Baden-Württemberg-LK-Calw.html)                                         | 799           |             27 |                    12 |
| [Germany: Baden-Württemberg : LK Böblingen](html/Germany-Baden-Württemberg-LK-Böblingen.html)                               | 1,617         |             47 |                    54 |
| [Germany: Baden-Württemberg : LK Alb-Donau-Kreis](html/Germany-Baden-Württemberg-LK-Alb-Donau-Kreis.html)                   | 728           |             27 |                    16 |
| [Germany: Baden-Württemberg : LK Emmendingen](html/Germany-Baden-Württemberg-LK-Emmendingen.html)                           | 570           |             43 |                     3 |
| [Germany: Baden-Württemberg : LK Breisgau-Hochschwarzwald](html/Germany-Baden-Württemberg-LK-Breisgau-Hochschwarzwald.html) | 1,196         |             71 |                     8 |
| [Germany: Baden-Württemberg : LK Freudenstadt](html/Germany-Baden-Württemberg-LK-Freudenstadt.html)                         | 604           |             39 |                    10 |
| [Germany: Baden-Württemberg : LK Esslingen](html/Germany-Baden-Württemberg-LK-Esslingen.html)                               | 2,026         |            120 |                    47 |
