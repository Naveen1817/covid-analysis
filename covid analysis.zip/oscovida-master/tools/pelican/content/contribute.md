Title: Contributions welcome!
Date: 2020-04-10 22:00
tags: about
slug: contribute

* Bugs and ideas can be reported as a
  ["New issue"](https://github.com/oscovida/oscovida/issues) in the OSCOVIDA Issue tracker. A [github](http://github.com) account is necessary.

* For those with programming and software engineering skills, there is a
  document
  [info.md](https://github.com/oscovida/oscovida/blob/master/info.md)
  with more details about the project. 
  
* Issues to work on can be taken from the 
  [OSCOVIDA issue tracker](https://github.com/oscovida/oscovida/issues).
  For historical reasons, there is also a stale 
  [todo list](https://github.com/oscovida/oscovida/blob/master/todo.md).
  


