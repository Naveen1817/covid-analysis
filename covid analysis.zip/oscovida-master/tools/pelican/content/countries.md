title: Tracking plots:  Countries of the world
tags: Data, Plots, Tracking plots:  Countries of the world
save-as: countries
slug: countries
date: 2020/08/22 00:49


| Location                                             | Total cases   | Total deaths   | New cases last week   |
|:-----------------------------------------------------|:--------------|:---------------|:----------------------|
| [Andorra](html/Andorra.html)                         | 1,024         | 53             | 43                    |
| [Antigua and Barbuda](html/Antigua-and-Barbuda.html) | 94            | 3              | 2                     |
| [Armenia](html/Armenia.html)                         | 42,319        | 836            | 1,296                 |
| [Albania](html/Albania.html)                         | 7,967         | 238            | 996                   |
| [Australia](html/Australia.html)                     | 24,407        | 472            | 1,665                 |
| [Afghanistan](html/Afghanistan.html)                 | 37,856        | 1,385          | 432                   |
| [Algeria](html/Algeria.html)                         | 40,258        | 1,411          | 3,071                 |
| [Argentina](html/Argentina.html)                     | 320,884       | 6,517          | 44,812                |
| [Austria](html/Austria.html)                         | 24,431        | 729            | 1,837                 |
| [Angola](html/Angola.html)                           | 2,044         | 93             | 229                   |
